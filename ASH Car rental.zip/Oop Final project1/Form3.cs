﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Oop_Final_project
{
    public partial class Form3 : Form
    {
        private OleDbConnection connection1 = new OleDbConnection();
        private OleDbConnection connection2 = new OleDbConnection();
        public Form3()
        {
            InitializeComponent();
            connection1.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Hassan Khan\Desktop\OOP\Oop Final project1\BusinessCars.accdb";
            connection2.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Hassan Khan\Desktop\OOP\Oop Final project1\EconomyCars.accdb";

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
             

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load_1(object sender, EventArgs e)
        {
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            label4.Visible = false;
            comboBox1.Items.Add("Business Class");
            comboBox1.Items.Add("Economy Class");
            //timer1.Start();
        }
        public static string sendtext = "";
        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Visible = true;
            label4.Visible = true; 
            if(comboBox2.SelectedIndex>comboBox3.SelectedIndex)
            {
                Variables.difference = comboBox2.SelectedIndex - comboBox3.SelectedIndex;
            }
            else
            {
                Variables.difference = comboBox3.SelectedIndex - comboBox2.SelectedIndex;
            }
            Variables.km = (Variables.difference * 10) / 2.0;
            Variables.time = (Variables.km * 3) / 0.75;
            Variables.fare_economy = (Variables.km * 13.5) + 30.78 + Variables.time;
            Variables.fare_business = (Variables.km * 20.0) + 38.78 + Variables.time;
            Random r3 = new Random();
            int arrival_time = r3.Next(1, 15);
            textBox1.Text+="Pickup Location: ";            
            textBox1.Text += comboBox2.SelectedItem.ToString() + Environment.NewLine ;
            textBox1.Text += "Drop-off Location: ";
            textBox1.Text += comboBox3.SelectedItem.ToString() + Environment.NewLine + Environment.NewLine;
            textBox1.Text += "----Your Ride's Details----" + Environment.NewLine + Environment.NewLine;
            Random r = new Random();
            int booking = r.Next(1, Variables.a);
            if (comboBox1.SelectedIndex == 0)
            {
                try
                {
                    connection1.Open();
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = connection1;
                    string query = "select * from BusinessClass where Serial_Number =" + booking + "  ";
                    command.CommandText = query;
                    OleDbDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        textBox1.Text += "Car: ";
                        textBox1.Text += reader["Car"].ToString() + Environment.NewLine;
                        textBox1.Text += "Car's Captain: ";
                        textBox1.Text += reader["Driver_Name"].ToString() + Environment.NewLine;
                        textBox1.Text += "Reg Number: ";
                        textBox1.Text += reader["CarReg_Number"].ToString() + Environment.NewLine;
                        textBox1.Text += "Color: ";
                        textBox1.Text += reader["Color"].ToString() + Environment.NewLine;
                        textBox1.Text += "Captain's Contact: ";
                        textBox1.Text += reader["Driver_ContactNumber"].ToString() + Environment.NewLine;
                        textBox1.Text += "Fare Estimate: Rs=" + Variables.fare_business + Environment.NewLine;
                        textBox1.Text += "Estimated journey time: " + Variables.time + " Minutes" + Environment.NewLine;
                        textBox1.Text += "Captian is arriving at your pick-up location in " + arrival_time + " Minutes" + Environment.NewLine + Environment.NewLine;
                        textBox1.Text += "-------------------------------------------------------------------------------------------------" + Environment.NewLine;
                        textBox1.Text += "Thankyou for choosing ASH.Ltd, Have a safe trip!";
                    }
                    connection1.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error " + ex);
                }
            }
            Random r2 = new Random();
            int booking2 = r2.Next(1, Variables.b);
            if (comboBox1.SelectedIndex == 1)
            {
                try
                {
                    connection2.Open();
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = connection2;
                    string query1 = "select * from EconomyCars where SerialNumber =" + booking2 + "  ";
                    command.CommandText = query1;
                    OleDbDataReader reader1 = command.ExecuteReader();
                    while (reader1.Read())
                    {
                        textBox1.Text += "Car: ";
                        textBox1.Text += reader1["Car"].ToString() + Environment.NewLine;
                        textBox1.Text += "Car's Captain: ";
                        textBox1.Text += reader1["DriversName"].ToString() + Environment.NewLine;
                        textBox1.Text += "Reg Number: ";
                        textBox1.Text += reader1["CarRegNumber"].ToString() + Environment.NewLine;
                        textBox1.Text += "Color: ";
                        textBox1.Text += reader1["Color"].ToString() + Environment.NewLine;
                        textBox1.Text += "Captain's Contact: ";
                        textBox1.Text += reader1["DriversContactNumber"].ToString() + Environment.NewLine;
                        textBox1.Text += "Fare Estimate: Rs=" + Variables.fare_economy + Environment.NewLine;
                        textBox1.Text += "Estimated journey time: " + Variables.time + " Minutes" + Environment.NewLine;
                        textBox1.Text += "Captian is arriving at your pick-up location in " + arrival_time + " Minutes" + Environment.NewLine;
                        textBox1.Text += "-------------------------------------------------------------------------------------------------" + Environment.NewLine;
                        textBox1.Text += "Thankyou for choosing ASH.Ltd, Have a safe trip!";
                    }
                    connection2.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error " + ex);
                }
                        
            }
            sendtext = textBox1.Text;
            Form5 frm = new Form5();
            //frm.Show();
            timer1.Start();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            this.Hide();
            f5.Show();
            timer1.Stop();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
                          
        }
    }   
}

        
  
