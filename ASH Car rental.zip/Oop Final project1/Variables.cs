﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oop_Final_project
{
    class Variables
    {
        public static int a = 6;
        public static int b = 5;
        public static int difference;
        public static double km;
        public static double time;
        public static double fare_business;
        public static double fare_economy;
    }
}
