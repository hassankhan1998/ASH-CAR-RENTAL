﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Oop_Final_project
{
    public partial class Login : Form
    {
        private OleDbConnection connection = new OleDbConnection();

        public Login()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Hassan Khan\Desktop\OOP\Oop Final project1\Login.accdb"; 
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {
            connection.Open();
            check_connection.Text = "Connection Successful";
            connection.Close();
        }

        private void login_button_Click(object sender, EventArgs e)
        {
            connection.Open();

            OleDbCommand command = new OleDbCommand();

            command.Connection = connection;

            command.CommandText = "Select * From Table1 where USERNAME ='" + textBox1.Text + "' and PASSWORD = '" + textBox2.Text + "' ";

            OleDbDataReader reader = command.ExecuteReader();

            int count = 0;

            while (reader.Read())
            {
                count++;

            }
            if (count == 1)
            {

                MessageBox.Show("Username And Password is Correct");

                Form2 second = new Form2();

                second.Show();

                this.Hide();
            }
            else if (count > 1)
            {
                MessageBox.Show("Not Accepted more than one especiall SANA KONSI WALI");

            }
            else
            {
                MessageBox.Show("Username and Password is not correct");
            }

            connection.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
