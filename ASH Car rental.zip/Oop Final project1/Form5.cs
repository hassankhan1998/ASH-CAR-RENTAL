﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Oop_Final_project
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            textBox1.Text = Form3.sendtext;
            Random r4 = new Random();
            int picture_box = r4.Next(1, 6);
            if(picture_box==1)
            {
                pictureBox1.Visible = true;
            }
            else if (picture_box == 2)
            {
                pictureBox2.Visible = true;
            }
            else if (picture_box == 3)
            {
                pictureBox3.Visible = true;
            }
            else if (picture_box == 4)
            {
                pictureBox4.Visible = true;
            }
            else if (picture_box == 5)
            {
                pictureBox5.Visible = true;
            }
            else 
            {
                pictureBox6.Visible = true;
            }
        }
    }
}
