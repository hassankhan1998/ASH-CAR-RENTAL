﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Oop_Final_project
{
    public partial class DriverREG : Form
    {
        private OleDbConnection connection1 = new OleDbConnection();
        private OleDbConnection connection2 = new OleDbConnection();
        public DriverREG()
        {
            InitializeComponent();
            connection1.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\\Mac\Home\Desktop\Oop Final project1\BusinessCars.accdb";
            connection2.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\\Mac\Home\Desktop\Oop Final project1\EconomyCars.accdb";

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void DriverREG_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == "Business Class")
            {

                connection1.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection1;
                string query = "insert into BusinessClass(Driver_Name,Car,CarReg_Number,Driver_ContactNumber) values('"+Drivername.Text+ "','" + Cartext.Text + "','" + Carregnumber.Text + "','" + Contactnumber.Text + "') ";
                command.CommandText = query;
                command.ExecuteNonQuery();

                MessageBox.Show("Congratulations! You have been registered as a Driver");
                Variables.a++;
                connection1.Close();
                    
            }
            else
            {
                connection2.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection2;
                string query = "insert into EconomyClass(Driver_Name,Car,CarReg_Number,Driver_ContactNumb,CNIC) values('" + Drivername.Text + "','" + Cartext.Text + "','" + Carregnumber.Text + "','" + Contactnumber.Text + "','" + cnictext.Text + "') ";
                command.CommandText = query;
                command.ExecuteNonQuery();

                MessageBox.Show("Congratulations! You have been registered as a Driver");
                Variables.b++;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
